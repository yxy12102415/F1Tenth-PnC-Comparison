#!/usr/bin/env bash
# Single-car Fitzpatrick static planning benchmark, official headless Gym.
set -euo pipefail
sim_dir="$(cd "$(dirname "$0")" && pwd)"
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 MPLBACKEND=Agg
python_bin="${FITZ_PYTHON:-python3}"
"$python_bin" "$sim_dir/tools/generate_takeover_assets.py" Fitzpatrick_sim >/dev/null
bash "$sim_dir/tools/build_fitz_tracking_joint.sh" >/dev/null
exec "$python_bin" "$sim_dir/tools/run_fitz_local.py" "$@"
